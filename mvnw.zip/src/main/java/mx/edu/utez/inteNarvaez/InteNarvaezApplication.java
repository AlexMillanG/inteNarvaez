package mx.edu.utez.inteNarvaez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InteNarvaezApplication {

	public static void main(String[] args) {
		SpringApplication.run(InteNarvaezApplication.class, args);
	}

}
