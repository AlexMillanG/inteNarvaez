package mx.edu.utez.inteNarvaez.models.email;

import jakarta.mail.MessagingException;
import mx.edu.utez.inteNarvaez.config.ApiResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;

public interface emailsRepository  {


}
