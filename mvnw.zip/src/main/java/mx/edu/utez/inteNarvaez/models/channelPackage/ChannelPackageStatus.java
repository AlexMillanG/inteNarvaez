package mx.edu.utez.inteNarvaez.models.channelPackage;

public enum ChannelPackageStatus {
    DISPONIBLE,
    OBSOLETO,
    DESCONTINUADO
}
